#!/data/data/com.termux/files/usr/bin/bash
# Quick deploy script for GitHub Pages from Termux

echo "=== Deploying to GitHub Pages ==="

if [ ! -d .git ]; then
  echo "❌ Not a git repository. Run this inside your username.github.io folder."
  exit 1
fi

read -p "Enter commit message (leave blank for auto): " COMMIT_MSG

if [ -z "$COMMIT_MSG" ]; then
  COMMIT_MSG="Auto-update: $(date '+%Y-%m-%d %H:%M:%S')"
fi

git add .
git commit -m "$COMMIT_MSG" || echo "No changes to commit"
git push origin main || git push origin master

echo "$(date '+%Y-%m-%d %H:%M:%S') - $COMMIT_MSG" >> deploy.log

echo "✅ Deployment complete!"
echo "🌍 Visit your site: https://$(git config user.name).github.io"
